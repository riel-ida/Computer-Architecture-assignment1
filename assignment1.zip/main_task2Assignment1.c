#include <stdio.h>
#define	MAX_LEN 34			/* maximal input string size */
					/* enough to get 32-bit string + '\n' + null terminator */
extern void assFunc(int x, int y);

int main(int argc, char** argv)
{
    char buf_x[MAX_LEN];
    char buf_y[MAX_LEN];
    int x;
    int y;
    
    fgets(buf_x, MAX_LEN, stdin);		/* get user first input  */ 
    sscanf(buf_x, "%d", &x);                    /* convert char to int */
    
    fgets(buf_y, MAX_LEN, stdin);		/* get user second input  */ 
    sscanf(buf_y, "%d", &y);                    /* convert char to int */
    
    assFunc(x, y);			/* call assembly function */ 

    return 0;
}